# pelisalacarta

## Skin python version

This is the new version of pelisalacarta, designed for using the great abilities of Kodi to make UIs using skins.

Elements on this folder are planned so you can copy them OVER the files on the main-classic version, some files will be replacements (like addon.xml) and other files will be additions (like the skin itself).